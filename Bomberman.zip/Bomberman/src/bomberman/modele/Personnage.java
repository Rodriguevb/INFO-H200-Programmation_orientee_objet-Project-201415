package bomberman.modele;


public class Personnage extends PossedePosition {

	
	public Personnage(int x, int y) {
		super(x,y);
	}
}